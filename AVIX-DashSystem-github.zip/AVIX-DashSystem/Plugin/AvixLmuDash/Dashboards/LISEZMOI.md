Mets ici les dashboards `.simhubdash` à installer : l'installeur les copie dans `SimHub\DashTemplates`
(ceux déjà présents sont conservés). Ils ne sont pas publiés sur GitHub (dashboards d'autres auteurs).
