Mets ici les polices (.ttf / .otf) à installer : l'installeur les copie dans `SimHub\DashFonts` et dans Windows.
Elles ne sont pas publiées sur GitHub (beaucoup sont commerciales).
