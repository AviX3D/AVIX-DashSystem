# AVIX LMU Dash Switcher

Plugin **SimHub** pour **Le Mans Ultimate** : le dashboard de tes écrans change tout seul selon la voiture
que tu pilotes (Ferrari 499P → dash 499P, BMW M4 GT3 → dash M4…).

Version **1.1.0** — par AVIX 3D

## Fonctionnement

- Le plugin lit le **vrai modèle** de la voiture dans la télémétrie native de LMU (`mVehicleModel`) et sa
  **classe** (Hypercar / LMP2 / LMP3 / GTE / GT3). Dans LMU, l'« ID voiture » de SimHub est le nom de la
  livrée (ex. `GT3_Akkodis ASP Team 2026_78`) : la playlist par voiture de SimHub ne suffit donc pas.
- Il crée **un seul dashboard, « AVIX LMU Auto »**, qui contient tous les dashboards voitures. Tu le mets sur
  tous tes écrans et il affiche le dash de la voiture pilotée.
- **Tactile VoCore** : moitié gauche de l'écran = page précédente, moitié droite = page suivante.
- Si le modèle n'est pas lisible, il se rabat sur des mots-clés d'équipe (AF Corse → Ferrari, Akkodis → Lexus…).
- Les règles voiture → dashboard sont modifiables dans la page du plugin.

## Installation

1. Télécharge le dépôt (**Code → Download ZIP**) et dézippe-le.
2. *(Optionnel)* Mets tes polices dans `Plugin/AvixLmuDash/Fonts` et tes `.simhubdash` dans `Plugin/AvixLmuDash/Dashboards`.
3. Lance **`AvixInstaller.exe`** : il ferme SimHub, copie le plugin, installe polices et dashboards, puis relance SimHub.
4. Au démarrage, SimHub demande d'activer le nouveau plugin : réponds **Oui**.
5. Menu de gauche **« AVIX LMU Dash »** → bouton **« Mettre « AVIX LMU Auto » sur mes écrans + activer le tactile »**.

Installation manuelle : copie `Plugin/AvixLmuDashSwitcher.dll` **et** le dossier `Plugin/AvixLmuDash` dans le dossier de
SimHub (`C:\Program Files (x86)\SimHub`), puis lance SimHub.

## Dashboards attendus par les règles par défaut

| Classe | Dashboards (nom du dossier dans `DashTemplates`) |
|---|---|
| Hypercar | Ferrari 499P - V2.0, Toyota GR010 Hybrid, HY Porsche 963 LMDh, HY BMW Hybrid V8 new version, Cadillac V-Series - LMU, Peugeot 9X8, Alpine A424 LMDh, Lamborghini SC63, Isotta Fraschini Tipo 6 LMH, Glickenhaus, Vanwall 680, HY Aston Martin Valkyrie LMH, HY Genesis GMR-001 |
| LMGTE | Ferrari 488GTE, Corvette C8.R - LMU, Aston Martin Vantage GTE - LMU, Porsche 911 RSR |
| LMGT3 | LMGT3 BMW M4, LMGT3 Ferrari 296, LMGT3 Porsche 911 GT3 R - standard size DDU, LMGT3 Lexus RC F GT3, LMGT3 McLaren 720S, LMGT3 Mercedes AMG GT3, LMGT3 Chevrolet Corvette Z06, LMGT3 Lamborghini Huracan GT3 Evo 2, LMGT3 Aston Martin |
| LMP2 | LMP2 LMU |
| LMP3 | LMP3 Ginetta G61, LMP3 Ligier JS P325.simhubdash |

## Propriétés SimHub

`AvixLmuDashPlugin.VehicleModel`, `.CarClass`, `.CarId`, `.Dashboard`, `.MasterSlot`, `.Status`
— action mappable : `AvixLmuDashPlugin.ReapplyDashboard`.

## Désinstaller

Supprime `AvixLmuDashSwitcher.dll`, le dossier `AvixLmuDash` et le dashboard `AVIX LMU Auto` dans SimHub.

## Compiler

Code C# (.NET Framework 4.8) dans `Source/`. Compilation avec `mcs` (Mono) contre les DLL de SimHub
(`SimHub.Plugins.dll`, `GameReaderCommon.dll`, `SimHub.Logging.dll`, `log4net.dll`, `Newtonsoft.Json.dll`)
et les assemblies de référence .NET 4.8 : voir `Source/build.sh`.
