#!/bin/bash
set -e
cd "$(dirname "$0")"
R=refs/net48; S=refs/simhub
NET="-r:$R/mscorlib.dll -r:$R/System.dll -r:$R/System.Core.dll -r:$R/System.Xaml.dll -r:$R/WindowsBase.dll -r:$R/PresentationCore.dll -r:$R/PresentationFramework.dll -r:$R/System.Xml.dll -r:$R/System.Drawing.dll -r:$R/System.IO.Compression.dll -r:$R/System.IO.Compression.FileSystem.dll -r:$R/netstandard.dll -r:$R/System.Runtime.dll"
mkdir -p build
mcs -nostdlib -noconfig -target:library -langversion:7 -codepage:utf8 -optimize+ -nowarn:618 -out:build/AvixLmuDashSwitcher.dll $NET \
  -r:$S/SimHub.Plugins.dll -r:$S/GameReaderCommon.dll -r:$S/SimHub.Logging.dll -r:$S/log4net.dll -r:$S/Newtonsoft.Json.dll \
  src/Plugin/*.cs src/Shared/*.cs
mcs -nostdlib -noconfig -target:exe -platform:anycpu -langversion:7 -codepage:utf8 -optimize+ -out:build/AvixInstaller.exe $NET \
  src/Installer/*.cs src/Shared/*.cs
